#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menuPrincipal();


// FUNCION PARA EL SWITCH DE REPORTES
void reporte();


#endif // MENU_INCLUDED
